
import turtle

turtle.shape('turtle')


step=50
angle = 4
for i in range(angle):
    turtle.forward(step)
    turtle.left(360/angle)
    
    
    

turtle.hideturtle()
