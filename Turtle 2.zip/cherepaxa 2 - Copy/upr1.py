import turtle as t
import random as r
import time

t.shape('turtle')
t.color('red')

t.speed(1000)
step=20
for i in range(1000):
    a=r.randint(0,360)
    t.fd(step)
    t.lt(a)
